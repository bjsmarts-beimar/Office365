/* tslint:disable */
require('./HelloWorldWebPart.module.css');
const styles = {
  helloWorld: 'helloWorld_1ccad006',
  container: 'container_1ccad006',
  row: 'row_1ccad006',
  column: 'column_1ccad006',
  'ms-Grid': 'ms-Grid_1ccad006',
  title: 'title_1ccad006',
  subTitle: 'subTitle_1ccad006',
  description: 'description_1ccad006',
  button: 'button_1ccad006',
  label: 'label_1ccad006',
};

export default styles;
/* tslint:enable */