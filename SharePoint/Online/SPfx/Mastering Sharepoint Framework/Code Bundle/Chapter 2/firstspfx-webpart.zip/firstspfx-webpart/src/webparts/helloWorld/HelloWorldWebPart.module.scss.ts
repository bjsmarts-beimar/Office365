/* tslint:disable */
require('./HelloWorldWebPart.module.css');
const styles = {
  helloWorld: 'helloWorld_6fc4f8e5',
  container: 'container_6fc4f8e5',
  row: 'row_6fc4f8e5',
  column: 'column_6fc4f8e5',
  'ms-Grid': 'ms-Grid_6fc4f8e5',
  title: 'title_6fc4f8e5',
  subTitle: 'subTitle_6fc4f8e5',
  description: 'description_6fc4f8e5',
  button: 'button_6fc4f8e5',
  label: 'label_6fc4f8e5',
};

export default styles;
/* tslint:enable */