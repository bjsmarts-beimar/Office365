/* tslint:disable */
require("./HelloPnPWebPart.module.css");
const styles = {
  helloPnP: 'helloPnP_6ce760d0',
  container: 'container_6ce760d0',
  row: 'row_6ce760d0',
  column: 'column_6ce760d0',
  'ms-Grid': 'ms-Grid_6ce760d0',
  title: 'title_6ce760d0',
  subTitle: 'subTitle_6ce760d0',
  description: 'description_6ce760d0',
  button: 'button_6ce760d0',
  label: 'label_6ce760d0',
};

export default styles;
/* tslint:enable */