declare interface IHelloPnPWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HelloPnPWebPartStrings' {
  const strings: IHelloPnPWebPartStrings;
  export = strings;
}
