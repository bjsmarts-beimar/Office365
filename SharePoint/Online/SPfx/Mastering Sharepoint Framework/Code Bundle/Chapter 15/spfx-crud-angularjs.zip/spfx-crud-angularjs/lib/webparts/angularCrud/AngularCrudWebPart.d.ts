import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
import './app/app-module';
export interface IAngularCrudWebPartProps {
    listName: string;
}
export default class AngularCrudWebPart extends BaseClientSideWebPart<IAngularCrudWebPartProps> {
    private $injector;
    render(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
