export interface IListItem {
    Id: number;
    Title?: string;
    ETag?: string;
}
export interface IDataService {
    createItem(title: string, webUrl: string, listName: string): angular.IPromise<IListItem>;
    readItem(itemId: number, webUrl: string, listName: string): angular.IPromise<IListItem>;
    getLatestItemId(webUrl: string, listName: string): angular.IPromise<number>;
    updateItem(item: IListItem, webUrl: string, listName: string): angular.IPromise<{}>;
    deleteItem(item: IListItem, webUrl: string, listName: string): angular.IPromise<{}>;
}
export default class DataService implements IDataService {
    private $q;
    private $http;
    static $inject: string[];
    constructor($q: angular.IQService, $http: angular.IHttpService);
    private getRequestDigest(webUrl);
    private getListItemEntityTypeName(webUrl, listName);
    createItem(title: string, webUrl: string, listName: string): angular.IPromise<IListItem>;
    readItem(itemId: number, webUrl: string, listName: string): angular.IPromise<IListItem>;
    getLatestItemId(webUrl: string, listName: string): angular.IPromise<number>;
    updateItem(item: IListItem, webUrl: string, listName: string): angular.IPromise<{}>;
    deleteItem(item: IListItem, webUrl: string, listName: string): angular.IPromise<{}>;
}
