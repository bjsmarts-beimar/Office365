declare interface IAngularCrudWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'AngularCrudWebPartStrings' {
  const strings: IAngularCrudWebPartStrings;
  export = strings;
}
