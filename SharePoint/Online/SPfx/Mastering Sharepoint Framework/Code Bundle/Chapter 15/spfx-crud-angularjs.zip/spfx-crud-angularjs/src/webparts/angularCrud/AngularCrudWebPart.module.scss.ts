/* tslint:disable */
require('./AngularCrudWebPart.module.css');
const styles = {
  angularCrud: 'angularCrud_d78f042e',
  container: 'container_d78f042e',
  row: 'row_d78f042e',
  column: 'column_d78f042e',
  'ms-Grid': 'ms-Grid_d78f042e',
  title: 'title_d78f042e',
  subTitle: 'subTitle_d78f042e',
  description: 'description_d78f042e',
  button: 'button_d78f042e',
  label: 'label_d78f042e',
};

export default styles;
/* tslint:enable */