import { IDataService, IListItem } from './DataService';
export default class HomeController {
    private dataService;
    private $window;
    private $rootScope;
    private $scope;
    static $inject: string[];
    status: string;
    items: IListItem[];
    private webUrl;
    private listName;
    constructor(dataService: IDataService, $window: angular.IWindowService, $rootScope: angular.IRootScopeService, $scope: angular.IScope);
    private init(webUrl, listName, $scope);
    createItem(): void;
    readItem(): void;
    updateItem(): void;
    deleteItem(): void;
}
