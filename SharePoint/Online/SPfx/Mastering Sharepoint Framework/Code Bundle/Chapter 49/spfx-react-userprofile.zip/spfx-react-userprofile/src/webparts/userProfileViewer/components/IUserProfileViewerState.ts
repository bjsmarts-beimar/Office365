import { IUserProfile } from '../components/IUserProfile';

export interface IUserProfileViewerState {
    userProfileItems: IUserProfile;
}