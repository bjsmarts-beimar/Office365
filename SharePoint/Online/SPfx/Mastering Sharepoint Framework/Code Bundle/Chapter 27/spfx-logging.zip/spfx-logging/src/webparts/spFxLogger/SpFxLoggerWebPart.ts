import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './SpFxLoggerWebPart.module.scss';
import * as strings from 'SpFxLoggerWebPartStrings';

import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
const LOG_SOURCE: string = 'SPFxLogger';

export interface ISpFxLoggerWebPartProps {
  description: string;
}

export default class SpFxLoggerWebPart extends BaseClientSideWebPart<ISpFxLoggerWebPartProps> {

  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Hello world from SPFx Logger');
    Log.info(LOG_SOURCE, JSON.stringify(this.properties, undefined, 2));
    Log.info(LOG_SOURCE, `Access the strings as "${strings.BasicGroupName}"`);
    return Promise.resolve<void>();
  }

  public render(): void {
    this.domElement.innerHTML = `
      <div class="${ styles.spFxLogger }">
        <div class="${ styles.container }">
          <div class="${ styles.row }">
            <div class="${ styles.column }">
              <span class="${ styles.title }">Welcome to SharePoint!</span>
              <p class="${ styles.subTitle }">Customize SharePoint experiences using Web Parts.</p>
              <p class="${ styles.description }">${escape(this.properties.description)}</p>
              <a href="https://aka.ms/spfx" class="${ styles.button }">
                <span class="${ styles.label }">Learn more</span>
              </a>
            </div>
          </div>
        </div>
      </div>`;
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
