declare interface ISpFxLoggerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpFxLoggerWebPartStrings' {
  const strings: ISpFxLoggerWebPartStrings;
  export = strings;
}
