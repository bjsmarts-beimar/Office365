/* tslint:disable */
require('./SpFxLoggerWebPart.module.css');
const styles = {
  spFxLogger: 'spFxLogger_d48503a9',
  container: 'container_d48503a9',
  row: 'row_d48503a9',
  column: 'column_d48503a9',
  'ms-Grid': 'ms-Grid_d48503a9',
  title: 'title_d48503a9',
  subTitle: 'subTitle_d48503a9',
  description: 'description_d48503a9',
  button: 'button_d48503a9',
  label: 'label_d48503a9',
};

export default styles;
/* tslint:enable */