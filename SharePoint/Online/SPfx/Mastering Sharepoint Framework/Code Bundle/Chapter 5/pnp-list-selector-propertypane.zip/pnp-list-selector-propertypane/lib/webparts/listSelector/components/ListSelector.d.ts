/// <reference types="react" />
import * as React from 'react';
import { IListSelectorProps } from './IListSelectorProps';
export default class ListSelector extends React.Component<IListSelectorProps, {}> {
    render(): React.ReactElement<IListSelectorProps>;
}
