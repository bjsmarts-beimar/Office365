/* tslint:disable */
require("./ListSelector.module.css");
const styles = {
  listSelector: 'listSelector_e080207f',
  container: 'container_e080207f',
  row: 'row_e080207f',
  column: 'column_e080207f',
  'ms-Grid': 'ms-Grid_e080207f',
  title: 'title_e080207f',
  subTitle: 'subTitle_e080207f',
  description: 'description_e080207f',
  button: 'button_e080207f',
  label: 'label_e080207f',
};

export default styles;
/* tslint:enable */