export interface IListSelectorProps {
    description: string;
    list: string | string[];
}
