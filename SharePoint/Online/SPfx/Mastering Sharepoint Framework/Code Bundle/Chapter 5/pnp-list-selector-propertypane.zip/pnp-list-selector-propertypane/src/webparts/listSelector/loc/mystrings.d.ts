declare interface IListSelectorWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ListSelectorWebPartStrings' {
  const strings: IListSelectorWebPartStrings;
  export = strings;
}
