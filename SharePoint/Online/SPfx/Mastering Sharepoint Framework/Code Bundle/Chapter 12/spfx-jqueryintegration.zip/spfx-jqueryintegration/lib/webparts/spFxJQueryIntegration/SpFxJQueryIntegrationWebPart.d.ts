import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface ISpFxJQueryIntegrationWebPartProps {
    description: string;
}
export default class SpFxJQueryIntegrationWebPart extends BaseClientSideWebPart<ISpFxJQueryIntegrationWebPartProps> {
    constructor();
    render(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
