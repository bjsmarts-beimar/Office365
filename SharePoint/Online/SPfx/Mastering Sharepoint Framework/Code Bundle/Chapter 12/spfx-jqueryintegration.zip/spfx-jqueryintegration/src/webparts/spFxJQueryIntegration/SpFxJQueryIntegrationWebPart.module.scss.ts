/* tslint:disable */
require('./SpFxJQueryIntegrationWebPart.module.css');
const styles = {
  spFxJQueryIntegration: 'spFxJQueryIntegration_d5a9b473',
  container: 'container_d5a9b473',
  row: 'row_d5a9b473',
  column: 'column_d5a9b473',
  'ms-Grid': 'ms-Grid_d5a9b473',
  title: 'title_d5a9b473',
  subTitle: 'subTitle_d5a9b473',
  description: 'description_d5a9b473',
  button: 'button_d5a9b473',
  label: 'label_d5a9b473',
};

export default styles;
/* tslint:enable */