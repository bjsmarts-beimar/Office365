export default class AccordianTemplate {
    public static accordianHTML: string = `
        <div class="accordion-content">
            <h2>Node.js</h2>
            <div>
                Used to build and run the applications which is equivalent to the .Net
            </div>

            <h2>NPM Packages </h2>
            <div>
            	Installs modules and its dependencies (equivalent to Nuget Package)
            </div>

            <h2>Gulp</h2>
            <div>
            	Automates SPFx development and deployment tasks
            </div>

            <h2>Yeoman</h2>
            <div>
                Used as SPFx solution generator and builds required project structure
            </div>

            <h2>TypeScript</h2>
            <div>
            	Help to build the Applications which will be then compiled to clean JS code
            </div>

            <h2>Visual Studio Code</h2>
            <div>
            	Interface for working with SPFx solutions
            </div>
        </div>
    `
}
