export default class AccordianTemplate {
    static accordianHTML: string;
}
