declare interface ISpFxJQueryIntegrationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpFxJQueryIntegrationWebPartStrings' {
  const strings: ISpFxJQueryIntegrationWebPartStrings;
  export = strings;
}
