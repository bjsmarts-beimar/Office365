/* tslint:disable */
require('./CustomHeaderFooterApplicationCustomizer.module.css');
const styles = {
  app: 'app_e54d07eb',
  top: 'top_e54d07eb',
  bottom: 'bottom_e54d07eb',
};

export default styles;
/* tslint:enable */