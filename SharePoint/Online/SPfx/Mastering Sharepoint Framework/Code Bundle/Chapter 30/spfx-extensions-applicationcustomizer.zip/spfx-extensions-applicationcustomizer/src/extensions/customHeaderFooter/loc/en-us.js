define([], function() {
  return {
    "Title": "CustomHeaderFooterApplicationCustomizer"
  }
});