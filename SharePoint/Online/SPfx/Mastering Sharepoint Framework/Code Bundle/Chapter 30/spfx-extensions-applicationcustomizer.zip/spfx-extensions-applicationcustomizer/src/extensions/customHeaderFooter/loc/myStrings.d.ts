declare interface ICustomHeaderFooterApplicationCustomizerStrings {
  Title: string;
}

declare module 'CustomHeaderFooterApplicationCustomizerStrings' {
  const strings: ICustomHeaderFooterApplicationCustomizerStrings;
  export = strings;
}
