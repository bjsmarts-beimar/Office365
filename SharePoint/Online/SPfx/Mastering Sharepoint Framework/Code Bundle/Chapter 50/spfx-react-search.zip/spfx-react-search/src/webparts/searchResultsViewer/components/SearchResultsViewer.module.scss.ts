/* tslint:disable */
require('./SearchResultsViewer.module.css');
const styles = {
  searchResultsViewer: 'searchResultsViewer_34e364c7',
  container: 'container_34e364c7',
  row: 'row_34e364c7',
  column: 'column_34e364c7',
  'ms-Grid': 'ms-Grid_34e364c7',
  title: 'title_34e364c7',
  subTitle: 'subTitle_34e364c7',
  description: 'description_34e364c7',
  button: 'button_34e364c7',
  label: 'label_34e364c7',
};

export default styles;
/* tslint:enable */