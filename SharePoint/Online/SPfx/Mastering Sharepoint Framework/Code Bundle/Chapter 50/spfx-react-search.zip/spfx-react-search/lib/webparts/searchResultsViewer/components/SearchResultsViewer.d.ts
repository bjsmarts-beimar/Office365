/// <reference types="react" />
import * as React from 'react';
import { ISearchResultsViewerProps } from './ISearchResultsViewerProps';
import { ISearchResultsViewerState } from './ISearchResultsViewerState';
export default class SearchResultsViewer extends React.Component<ISearchResultsViewerProps, ISearchResultsViewerState> {
    private _searchService;
    constructor(props: ISearchResultsViewerProps, state: ISearchResultsViewerState);
    render(): React.ReactElement<ISearchResultsViewerProps>;
    private _searchClicked();
    private _onRenderCell(item, index, isScrolling);
}
