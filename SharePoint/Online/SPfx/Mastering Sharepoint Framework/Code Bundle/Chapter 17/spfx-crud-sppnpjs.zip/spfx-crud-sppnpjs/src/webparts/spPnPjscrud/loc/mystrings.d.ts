declare interface ISpPnPjscrudWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'SpPnPjscrudWebPartStrings' {
  const strings: ISpPnPjscrudWebPartStrings;
  export = strings;
}
