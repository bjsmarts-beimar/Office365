/* tslint:disable */
require('./SpPnPjscrudWebPart.module.css');
const styles = {
  spPnPjscrud: 'spPnPjscrud_bdb680fa',
  container: 'container_bdb680fa',
  row: 'row_bdb680fa',
  column: 'column_bdb680fa',
  'ms-Grid': 'ms-Grid_bdb680fa',
  title: 'title_bdb680fa',
  subTitle: 'subTitle_bdb680fa',
  description: 'description_bdb680fa',
  button: 'button_bdb680fa',
  label: 'label_bdb680fa',
};

export default styles;
/* tslint:enable */