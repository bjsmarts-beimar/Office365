export interface IListItem {
    Title?: string;
    Id: number;
}
