import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface ISpPnPjscrudWebPartProps {
    listName: string;
}
export default class SpPnPjscrudWebPart extends BaseClientSideWebPart<ISpPnPjscrudWebPartProps> {
    render(): void;
    private setButtonsEventHandlers();
    private getLatestItemId();
    private updateStatus(status, items?);
    private updateItemsHtml(items);
    private createItem();
    private readItem();
    private updateItem();
    private deleteItem();
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
