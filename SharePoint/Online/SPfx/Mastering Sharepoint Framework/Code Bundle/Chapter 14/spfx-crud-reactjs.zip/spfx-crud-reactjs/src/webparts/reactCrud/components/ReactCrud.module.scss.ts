/* tslint:disable */
require('./ReactCrud.module.css');
const styles = {
  reactCrud: 'reactCrud_03c23a87',
  container: 'container_03c23a87',
  row: 'row_03c23a87',
  column: 'column_03c23a87',
  'ms-Grid': 'ms-Grid_03c23a87',
  title: 'title_03c23a87',
  subTitle: 'subTitle_03c23a87',
  description: 'description_03c23a87',
  button: 'button_03c23a87',
  label: 'label_03c23a87',
};

export default styles;
/* tslint:enable */