export interface ISpFxTestProps {
  description: string;
}
