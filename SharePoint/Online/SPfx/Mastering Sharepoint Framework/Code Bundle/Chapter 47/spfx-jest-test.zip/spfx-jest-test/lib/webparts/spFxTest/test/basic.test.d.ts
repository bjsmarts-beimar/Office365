export {};
//# sourceMappingURL=basic.test.d.ts.map