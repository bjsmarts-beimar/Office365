import * as React from 'react';
import { ISpFxTestProps } from './ISpFxTestProps';
export default class SpFxTest extends React.Component<ISpFxTestProps, {}> {
    render(): React.ReactElement<ISpFxTestProps>;
}
//# sourceMappingURL=SpFxTest.d.ts.map