declare interface ISpFxTestWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpFxTestWebPartStrings' {
  const strings: ISpFxTestWebPartStrings;
  export = strings;
}
