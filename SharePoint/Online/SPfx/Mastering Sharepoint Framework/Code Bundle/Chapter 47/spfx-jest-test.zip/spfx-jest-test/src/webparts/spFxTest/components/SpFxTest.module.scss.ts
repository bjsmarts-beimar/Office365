/* tslint:disable */
require("./SpFxTest.module.css");
const styles = {
  spFxTest: 'spFxTest_db1fbe5b',
  container: 'container_db1fbe5b',
  row: 'row_db1fbe5b',
  column: 'column_db1fbe5b',
  'ms-Grid': 'ms-Grid_db1fbe5b',
  title: 'title_db1fbe5b',
  subTitle: 'subTitle_db1fbe5b',
  description: 'description_db1fbe5b',
  button: 'button_db1fbe5b',
  label: 'label_db1fbe5b',
};

export default styles;
/* tslint:enable */