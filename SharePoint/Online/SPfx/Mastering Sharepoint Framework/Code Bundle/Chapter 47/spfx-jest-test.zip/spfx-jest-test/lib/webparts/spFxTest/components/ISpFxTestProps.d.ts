export interface ISpFxTestProps {
    description: string;
}
//# sourceMappingURL=ISpFxTestProps.d.ts.map