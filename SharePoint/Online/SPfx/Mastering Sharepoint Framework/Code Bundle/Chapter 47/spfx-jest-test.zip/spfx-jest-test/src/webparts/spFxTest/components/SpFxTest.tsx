import * as React from 'react';
import styles from './SpFxTest.module.scss';
import { ISpFxTestProps } from './ISpFxTestProps';
import { escape } from '@microsoft/sp-lodash-subset';

export default class SpFxTest extends React.Component<ISpFxTestProps, {}> {
  public render(): React.ReactElement<ISpFxTestProps> {
    return (
      <div className={ styles.spFxTest } id="spfxTest">
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>
              <span className={ styles.title }>Welcome to SharePoint!</span>
              <p className={ styles.subTitle }>Customize SharePoint experiences using Web Parts.</p>
              <h1 className={styles.title}>SPFx Test webpart</h1>
              <p className={ styles.description }>{escape(this.props.description)}</p>
              <a href="https://aka.ms/spfx" className={ styles.button }>
                <span className={ styles.label }>Learn more</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
