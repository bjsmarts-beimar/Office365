import { IUserItem } from './IUserItem';

export interface IConsumeMsGraphState {
    users: Array<IUserItem>;
}