/// <reference types="react" />
import * as React from 'react';
import { IConsumeMsGraphProps } from './IConsumeMsGraphProps';
import { IConsumeMsGraphState } from './IConsumeMsGraphState';
export default class ConsumeMsGraph extends React.Component<IConsumeMsGraphProps, IConsumeMsGraphState> {
    constructor(props: IConsumeMsGraphProps, state: IConsumeMsGraphState);
    render(): React.ReactElement<IConsumeMsGraphProps>;
    private getUserDetails();
}
