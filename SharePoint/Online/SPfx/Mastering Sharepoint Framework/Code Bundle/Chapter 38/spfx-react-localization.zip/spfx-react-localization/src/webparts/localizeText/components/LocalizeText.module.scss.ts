/* tslint:disable */
require('./LocalizeText.module.css');
const styles = {
  localizeText: 'localizeText_09abd44a',
  container: 'container_09abd44a',
  row: 'row_09abd44a',
  column: 'column_09abd44a',
  'ms-Grid': 'ms-Grid_09abd44a',
  title: 'title_09abd44a',
  subTitle: 'subTitle_09abd44a',
  description: 'description_09abd44a',
  button: 'button_09abd44a',
  label: 'label_09abd44a',
};

export default styles;
/* tslint:enable */