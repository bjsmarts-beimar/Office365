export interface ILocalizeTextProps {
    description: string;
}
