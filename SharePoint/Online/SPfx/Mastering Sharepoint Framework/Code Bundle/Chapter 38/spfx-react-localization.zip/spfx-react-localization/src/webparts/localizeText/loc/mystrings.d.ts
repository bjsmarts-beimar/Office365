declare interface ILocalizeTextWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  LearnMoreButtonLabel: string;
}

declare module 'LocalizeTextWebPartStrings' {
  const strings: ILocalizeTextWebPartStrings;
  export = strings;
}
