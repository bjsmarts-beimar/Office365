/// <reference types="react" />
import * as React from 'react';
import { ILocalizeTextProps } from './ILocalizeTextProps';
export default class LocalizeText extends React.Component<ILocalizeTextProps, {}> {
    render(): React.ReactElement<ILocalizeTextProps>;
}
