define([], function() {
    return {
      "PropertyPaneDescription": "Kuvaus",
      "BasicGroupName": "Ryhmän nimi",
      "DescriptionFieldLabel": "Kuvauskenttä",
      "LearnMoreButtonLabel": "Lisätietoja"
    }
  });