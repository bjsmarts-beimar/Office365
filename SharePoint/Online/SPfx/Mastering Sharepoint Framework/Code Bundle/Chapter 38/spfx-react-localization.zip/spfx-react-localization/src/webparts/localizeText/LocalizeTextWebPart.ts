import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';

import * as strings from 'LocalizeTextWebPartStrings';
import LocalizeText from './components/LocalizeText';
import { ILocalizeTextProps } from './components/ILocalizeTextProps';

export interface ILocalizeTextWebPartProps {
  description: string;
}

export default class LocalizeTextWebPart extends BaseClientSideWebPart<ILocalizeTextWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ILocalizeTextProps > = React.createElement(
      LocalizeText,
      {
        description: this.properties.description
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
