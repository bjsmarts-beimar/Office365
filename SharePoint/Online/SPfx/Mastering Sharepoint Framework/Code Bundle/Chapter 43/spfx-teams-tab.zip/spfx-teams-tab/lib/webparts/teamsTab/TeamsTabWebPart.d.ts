import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
export interface ITeamsTabWebPartProps {
    description: string;
}
export default class TeamsTabWebPart extends BaseClientSideWebPart<ITeamsTabWebPartProps> {
    private _teamsContext;
    protected onInit(): Promise<any>;
    render(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
