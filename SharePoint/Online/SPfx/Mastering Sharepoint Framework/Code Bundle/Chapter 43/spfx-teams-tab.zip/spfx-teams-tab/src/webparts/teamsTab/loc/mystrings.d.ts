declare interface ITeamsTabWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TeamsTabWebPartStrings' {
  const strings: ITeamsTabWebPartStrings;
  export = strings;
}
