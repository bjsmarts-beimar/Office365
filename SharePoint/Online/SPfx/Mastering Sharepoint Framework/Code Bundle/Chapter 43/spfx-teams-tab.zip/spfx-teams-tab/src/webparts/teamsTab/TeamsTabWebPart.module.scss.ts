/* tslint:disable */
require("./TeamsTabWebPart.module.css");
const styles = {
  teamsTab: 'teamsTab_ac44e419',
  container: 'container_ac44e419',
  row: 'row_ac44e419',
  column: 'column_ac44e419',
  'ms-Grid': 'ms-Grid_ac44e419',
  title: 'title_ac44e419',
  subTitle: 'subTitle_ac44e419',
  description: 'description_ac44e419',
  button: 'button_ac44e419',
  label: 'label_ac44e419',
};

export default styles;
/* tslint:enable */