import * as React from 'react';
import styles from './OrgChartViewer.module.scss';
import { IOrgChartViewerProps } from './IOrgChartViewerProps';
import { IOrgChartViewerState } from './IOrgChartViewerState';
import { IOrgChartItem, ChartItem } from './IOrgChartItem';
import { IDataNode, OrgChartNode } from './OrgChartNode';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { escape } from '@microsoft/sp-lodash-subset';
import OrgChart from 'react-orgchart';

export default class OrgChartViewer extends React.Component<IOrgChartViewerProps, IOrgChartViewerState> {
  constructor(props: IOrgChartViewerProps, state: IOrgChartViewerState) {
    super(props);

    this.state = {
      orgChartItems: []
    };

    this.processOrgChartItems();
  }

  public render(): React.ReactElement<IOrgChartViewerProps> {
    return (
      <div className={ styles.orgChartViewer }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>

              <OrgChart tree={this.state.orgChartItems} NodeComponent={this.MyNodeComponent} />

            </div>
          </div>
        </div>
      </div>
    );
  }

  private MyNodeComponent = ({ node }) => {
    if (node.url) {
      return (
        <div className="initechNode">
          <a href={ node.url.Url } className={styles.link} >{ node.title }</a>        
        </div>
      );    
    }
    else {
      return (
        <div className="initechNode">{ node.title }</div>
      );    
    }    
  }  

  private readOrgChartItems(): Promise<IOrgChartItem[]> {
    return new Promise<IOrgChartItem[]>((resolve: (itemId: IOrgChartItem[]) => void, reject: (error: any) => void): void => {
      this.props.spHttpClient.get(`${this.props.siteUrl}/_api/web/lists/getbytitle('${this.props.listName}')/items?$select=Title,Id,Url,Parent/Id,Parent/Title&$expand=Parent/Id&$orderby=Parent/Id asc`,
      SPHttpClient.configurations.v1,
      {
        headers: {
          'Accept': 'application/json;odata=nometadata',
          'odata-version': ''
        }
      })
      .then((response: SPHttpClientResponse): Promise<{ value: IOrgChartItem[] }> => {
        return response.json();
      })
      .then((response: { value: IOrgChartItem[] }): void => {
        resolve(response.value);
      }, (error: any): void => {
        reject(error);
      });
    });    
  }

  private processOrgChartItems(): void {
    this.readOrgChartItems()
      .then((orgChartItems: IOrgChartItem[]): void => {

        let orgChartNodes: Array<ChartItem> = [];
        var count: number;
        for (count = 0; count < orgChartItems.length; count++) {
          orgChartNodes.push(new ChartItem(orgChartItems[count].Id, orgChartItems[count].Title, orgChartItems[count].Url, orgChartItems[count].Parent ? orgChartItems[count].Parent.Id : undefined));
        }

        var arrayToTree: any = require('array-to-tree');
        var orgChartHierarchyNodes: any = arrayToTree(orgChartNodes);
        var output: any = JSON.stringify(orgChartHierarchyNodes[0]);

        this.setState({
          orgChartItems: JSON.parse(output)
        });
      });
  }
}
