import { IDataNode } from './OrgChartNode';

export interface IOrgChartViewerState {
    orgChartItems: any;
}