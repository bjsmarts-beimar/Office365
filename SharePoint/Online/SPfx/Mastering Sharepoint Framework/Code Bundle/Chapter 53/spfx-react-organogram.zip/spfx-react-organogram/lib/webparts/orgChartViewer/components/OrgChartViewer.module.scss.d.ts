declare const styles: {
    orgChartViewer: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    link: string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
};
export default styles;
