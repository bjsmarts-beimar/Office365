export interface IDataNode {
    id: number;
    parent_id: number;
    name: string;
    children: Array<IDataNode>;
}
export declare class OrgChartNode implements IDataNode {
    id: number;
    parent_id: number;
    name: string;
    children: Array<IDataNode>;
    constructor(id: number, name: string, children?: Array<IDataNode>);
    addNode(node: IDataNode): void;
}
