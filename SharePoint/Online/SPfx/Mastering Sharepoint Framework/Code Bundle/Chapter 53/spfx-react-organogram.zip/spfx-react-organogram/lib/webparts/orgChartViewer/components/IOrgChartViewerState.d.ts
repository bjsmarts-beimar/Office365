export interface IOrgChartViewerState {
    orgChartItems: any;
}
