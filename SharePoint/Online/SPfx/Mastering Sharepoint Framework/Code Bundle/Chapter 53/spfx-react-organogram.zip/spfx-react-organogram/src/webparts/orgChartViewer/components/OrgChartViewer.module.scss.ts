/* tslint:disable */
require('./OrgChartViewer.module.css');
const styles = {
  orgChartViewer: 'orgChartViewer_3f18f649',
  container: 'container_3f18f649',
  row: 'row_3f18f649',
  column: 'column_3f18f649',
  'ms-Grid': 'ms-Grid_3f18f649',
  link: 'link_3f18f649',
  title: 'title_3f18f649',
  subTitle: 'subTitle_3f18f649',
  description: 'description_3f18f649',
  button: 'button_3f18f649',
  label: 'label_3f18f649',
};

export default styles;
/* tslint:enable */