declare interface IOrgChartViewerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'OrgChartViewerWebPartStrings' {
  const strings: IOrgChartViewerWebPartStrings;
  export = strings;
}
