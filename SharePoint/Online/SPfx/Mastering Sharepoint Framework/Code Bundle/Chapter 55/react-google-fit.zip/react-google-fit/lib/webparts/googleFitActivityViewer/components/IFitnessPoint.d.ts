export interface IFitnessPoint {
    dataTypeName: string;
    endTimeNanos: string;
    modifiedTimeMillis: string;
    value: any[];
}
