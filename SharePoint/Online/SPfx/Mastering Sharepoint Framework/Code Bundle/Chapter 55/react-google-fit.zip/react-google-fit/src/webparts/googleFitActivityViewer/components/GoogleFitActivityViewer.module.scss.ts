/* tslint:disable */
require("./GoogleFitActivityViewer.module.css");
const styles = {
  googleFitActivityViewer: 'googleFitActivityViewer_78160cc7',
  container: 'container_78160cc7',
  row: 'row_78160cc7',
  column: 'column_78160cc7',
  'ms-Grid': 'ms-Grid_78160cc7',
  title: 'title_78160cc7',
  subTitle: 'subTitle_78160cc7',
  description: 'description_78160cc7',
  button: 'button_78160cc7',
  label: 'label_78160cc7',
  msTable: 'msTable_78160cc7',
  msTableRow: 'msTableRow_78160cc7',
  msTableCell: 'msTableCell_78160cc7',
  msTableHead: 'msTableHead_78160cc7',
};

export default styles;
/* tslint:enable */