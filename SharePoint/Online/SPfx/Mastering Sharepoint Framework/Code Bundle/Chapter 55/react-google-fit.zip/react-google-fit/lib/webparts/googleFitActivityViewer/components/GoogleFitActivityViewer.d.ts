/// <reference types="react" />
import * as React from 'react';
import { IGoogleFitActivityViewerProps } from './IGoogleFitActivityViewerProps';
import { IGoogleFitActivityViewerState } from './IGoogleFitActivityViewerState';
export default class GoogleFitActivityViewer extends React.Component<IGoogleFitActivityViewerProps, IGoogleFitActivityViewerState> {
    private dataCenterServiceInstance;
    constructor(props: any);
    render(): React.ReactElement<IGoogleFitActivityViewerProps>;
    private readStepCount(accessToken);
    private readCalories(accessToken);
    private readDistance(accessToken);
    private readActivityTime(accessToken);
}
