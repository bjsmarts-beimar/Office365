import { ServiceScope } from '@microsoft/sp-core-library';

export interface IGoogleFitActivityViewerProps {
  clientId: string;
  serviceScope: ServiceScope;
}
