import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IGoogleFitActivityViewerWebPartProps {
    clientId: string;
}
export default class GoogleFitActivityViewerWebPart extends BaseClientSideWebPart<IGoogleFitActivityViewerWebPartProps> {
    render(): void;
    protected readonly disableReactivePropertyChanges: boolean;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
