declare interface IGoogleFitActivityViewerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ClientIdFieldLabel: string;
}

declare module 'GoogleFitActivityViewerWebPartStrings' {
  const strings: IGoogleFitActivityViewerWebPartStrings;
  export = strings;
}
