import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { IDataService } from './IDataService';
export declare class GoogleFitService implements IDataService {
    static readonly serviceKey: ServiceKey<IDataService>;
    private _httpClient;
    private _pageContext;
    private _currentWebUrl;
    constructor(serviceScope: ServiceScope);
    getStepCount(accessToken: string): Promise<number>;
    getCalories(accessToken: string): Promise<number>;
    getDistance(accessToken: string): Promise<number>;
    getActivityTime(accessToken: string): Promise<number>;
}
