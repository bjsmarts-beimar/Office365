export interface IGoogleFitActivityViewerState {
    isGoogleAuthenticated: boolean;
    accessToken: string;
    stepCount: number;
    calories: number;
    distance: number;
    activityTime: number;
}