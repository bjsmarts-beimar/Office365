define([], function () {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "ClientIdFieldLabel": "ClientId Field"
  }
});