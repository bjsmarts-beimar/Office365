declare const styles: {
    PercentFieldCustomizer: string;
    cell: string;
    full: string;
};
export default styles;
