declare interface IPercentFieldCustomizerFieldCustomizerStrings {
  Title: string;
}

declare module 'PercentFieldCustomizerFieldCustomizerStrings' {
  const strings: IPercentFieldCustomizerFieldCustomizerStrings;
  export = strings;
}
