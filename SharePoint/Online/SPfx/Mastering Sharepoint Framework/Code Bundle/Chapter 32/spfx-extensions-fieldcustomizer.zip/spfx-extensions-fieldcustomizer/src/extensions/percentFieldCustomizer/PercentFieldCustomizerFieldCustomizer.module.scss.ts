/* tslint:disable */
require('./PercentFieldCustomizerFieldCustomizer.module.css');
const styles = {
  PercentFieldCustomizer: 'PercentFieldCustomizer_8eedc940',
  cell: 'cell_8eedc940',
  full: 'full_8eedc940',
};

export default styles;
/* tslint:enable */