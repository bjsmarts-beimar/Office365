define([], function() {
  return {
    "Title": "PercentFieldCustomizerFieldCustomizer"
  }
});