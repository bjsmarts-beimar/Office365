define([], function() {
  return {
    "Title": "ReactHeaderFooterApplicationCustomizer"
  }
});