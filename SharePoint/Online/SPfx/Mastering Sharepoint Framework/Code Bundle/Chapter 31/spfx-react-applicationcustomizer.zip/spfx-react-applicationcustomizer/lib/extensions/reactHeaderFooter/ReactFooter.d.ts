/// <reference types="react" />
import * as React from "react";
export interface IReactFooterProps {
}
export default class ReactFooter extends React.Component<IReactFooterProps> {
    constructor(props: IReactFooterProps);
    render(): JSX.Element;
    private getItems;
}
