declare interface IReactHeaderFooterApplicationCustomizerStrings {
  Title: string;
}

declare module 'ReactHeaderFooterApplicationCustomizerStrings' {
  const strings: IReactHeaderFooterApplicationCustomizerStrings;
  export = strings;
}
