export interface IOrgChartItem {
    Title: string;
    Id: number;
    parent_id: number;
    Url?: string;
    Parent: any;
}
export declare class ChartItem {
    id: number;
    title: string;
    url: string;
    parent_id?: number;
    constructor(id: number, title: string, url: string, parent_id?: number);
}
