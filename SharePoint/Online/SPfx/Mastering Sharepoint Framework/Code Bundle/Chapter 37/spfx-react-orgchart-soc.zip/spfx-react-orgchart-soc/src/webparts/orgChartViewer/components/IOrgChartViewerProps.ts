import { ServiceScope } from '@microsoft/sp-core-library';

export interface IOrgChartViewerProps {
  listName: string;
  serviceScope: ServiceScope;
}
