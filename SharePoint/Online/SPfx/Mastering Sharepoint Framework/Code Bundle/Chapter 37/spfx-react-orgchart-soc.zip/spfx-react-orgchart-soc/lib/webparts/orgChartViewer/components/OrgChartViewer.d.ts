/// <reference types="react" />
import * as React from 'react';
import { IOrgChartViewerProps } from './IOrgChartViewerProps';
import { IOrgChartViewerState } from './IOrgChartViewerState';
export default class OrgChartViewer extends React.Component<IOrgChartViewerProps, IOrgChartViewerState> {
    private dataCenterServiceInstance;
    constructor(props: IOrgChartViewerProps, state: IOrgChartViewerState);
    render(): React.ReactElement<IOrgChartViewerProps>;
    private MyNodeComponent;
}
