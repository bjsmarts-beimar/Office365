import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { IOrgChartItem } from './IOrgChartItem';
import { IDataService } from './IDataService';
export declare class OrgChartService implements IDataService {
    static readonly serviceKey: ServiceKey<IDataService>;
    private _spHttpClient;
    private _pageContext;
    private _currentWebUrl;
    constructor(serviceScope: ServiceScope);
    getOrgChartInfo(listName?: string): Promise<IOrgChartItem[]>;
    private readOrgChartItems(listName);
    private processOrgChartItems(orgChartItems);
}
