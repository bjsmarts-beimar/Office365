import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { IDataService } from './IDataService';

export class MockDataService implements IDataService {
    public static readonly serviceKey: ServiceKey<IDataService> = ServiceKey.create<IDataService>('orgChart:mock-service', MockDataService);

    constructor(serviceScope: ServiceScope) {
    }

    public getOrgChartInfo(): Promise<any> {
        const initechOrg: any = 
          {
            id: 1,
            title: "ROOT",
            url: {Description: "Microsoft", Url: "http://www.microsoft.com"},
            children:[
              {
                id: 2,
                title: "Parent 1",
                url: null,
                parent_id: 1,
                children:[
                  { id: 3, title: "Child 11", parent_id: 2, url: null },
                  { id: 5, title: "Child 12", parent_id: 2, url: null },
                  { id: 6, title: "Child 13", parent_id: 2, url: null }
                ]
              },
              {
                id: 7,
                title: "Parent 2",
                url: null,
                parent_id: 1,
                children:[
                  { id: 8, title: "Child 21", parent_id: 7, url: null },
                  { id: 9, title: "Child 22", parent_id: 7, url: null }
                ]
              },
              {
                id: 10,
                title: "Parent 3",
                url: null,
                parent_id: 1,
                children:[
                  { id: 11, title: "Child 31", parent_id: 10, url: null },
                  { id: 12, title: "Child 32", parent_id: 10, url: null }
                ]
              }
            ]
          };
    
        return new Promise<any>((resolve, reject) => {
          resolve(JSON.parse(JSON.stringify(initechOrg)));
        });
      }
}