import { IOrgChartItem, ChartItem } from './IOrgChartItem';

export interface IDataService {
    getOrgChartInfo: (listName?: string) => Promise<any>;
}