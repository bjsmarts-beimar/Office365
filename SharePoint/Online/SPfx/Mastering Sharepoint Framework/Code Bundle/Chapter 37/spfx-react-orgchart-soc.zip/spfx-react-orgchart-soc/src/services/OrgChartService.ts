import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { IOrgChartItem, ChartItem } from './IOrgChartItem';
import { IDataService } from './IDataService';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { PageContext } from '@microsoft/sp-page-context';

export class OrgChartService implements IDataService {
    public static readonly serviceKey: ServiceKey<IDataService> = ServiceKey.create<IDataService>('orgChart:data-service', OrgChartService);
    private _spHttpClient: SPHttpClient;
    private _pageContext: PageContext;
    private _currentWebUrl: string;

    constructor(serviceScope: ServiceScope) {
        serviceScope.whenFinished(() => {
            // Configure the required dependencies
            this._spHttpClient = serviceScope.consume(SPHttpClient.serviceKey);
            this._pageContext = serviceScope.consume(PageContext.serviceKey);
            this._currentWebUrl = this._pageContext.web.absoluteUrl;
        });
    }

    public getOrgChartInfo(listName?: string): Promise<IOrgChartItem[]> {
      return new Promise<IOrgChartItem[]>((resolve: (itemId: IOrgChartItem[]) => void, reject: (error: any) => void): void => {
        this.readOrgChartItems(listName)
          .then((orgChartItems: IOrgChartItem[]): void => {
            resolve(this.processOrgChartItems(orgChartItems));
          });
      });
    }

    private readOrgChartItems(listName: string): Promise<IOrgChartItem[]> {
      return new Promise<IOrgChartItem[]>((resolve: (itemId: IOrgChartItem[]) => void, reject: (error: any) => void): void => {
        this._spHttpClient.get(`${this._currentWebUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Title,Id,URL,Parent/Id,Parent/Title&$expand=Parent/Id&$orderby=Parent/Id asc`,
        SPHttpClient.configurations.v1,
        {
          headers: {
            'Accept': 'application/json;odata=nometadata',
            'odata-version': ''
          }
        })
        .then((response: SPHttpClientResponse): Promise<{ value: IOrgChartItem[] }> => {
          return response.json();
        })
        .then((response: { value: IOrgChartItem[] }): void => {
          resolve(response.value);
        }, (error: any): void => {
          reject(error);
        });
      });    
    }
    
    private processOrgChartItems(orgChartItems: IOrgChartItem[]): any {
        let orgChartNodes: Array<ChartItem> = [];

        var count: number;
        for (count = 0; count < orgChartItems.length; count++) {
            orgChartNodes.push(new ChartItem(orgChartItems[count].Id, orgChartItems[count].Title, orgChartItems[count].Url, orgChartItems[count].Parent ? orgChartItems[count].Parent.Id : undefined));
        }

        var arrayToTree: any = require('array-to-tree');
        var orgChartHierarchyNodes: any = arrayToTree(orgChartNodes);
        var output: any = JSON.stringify(orgChartHierarchyNodes[0]);

        return JSON.parse(output);
    }
}