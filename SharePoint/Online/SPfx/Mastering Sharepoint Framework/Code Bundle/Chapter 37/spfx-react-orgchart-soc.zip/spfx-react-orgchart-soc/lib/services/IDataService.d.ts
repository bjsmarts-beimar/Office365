export interface IDataService {
    getOrgChartInfo: (listName?: string) => Promise<any>;
}
