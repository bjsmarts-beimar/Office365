import * as React from 'react';
import styles from './OrgChartViewer.module.scss';
import { IOrgChartViewerProps } from './IOrgChartViewerProps';
import { IOrgChartViewerState } from './IOrgChartViewerState';
import { IOrgChartItem, ChartItem } from '../../../services/IOrgChartItem';
import { IDataNode, OrgChartNode } from './OrgChartNode';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { escape } from '@microsoft/sp-lodash-subset';
import { ServiceScope, Environment, EnvironmentType } from '@microsoft/sp-core-library';
import { OrgChartService } from '../../../services/OrgChartService';
import { MockDataService } from '../../../services/MockDataService';
import { IDataService } from '../../../services/IDataService';
import OrgChart from 'react-orgchart';

export default class OrgChartViewer extends React.Component<IOrgChartViewerProps, IOrgChartViewerState> {
  private dataCenterServiceInstance: IDataService;

  constructor(props: IOrgChartViewerProps, state: IOrgChartViewerState) {
    super(props);

    this.state = {
      orgChartItems: []
    };

    let serviceScope: ServiceScope = this.props.serviceScope;

    switch (Environment.type) {	            
      case EnvironmentType.SharePoint:	            
      case EnvironmentType.ClassicSharePoint: 
        // Based on the type of environment, return the correct instance of the IDataCenterService interface
        // Mapping to be used when webpart runs in SharePoint.
        this.dataCenterServiceInstance = serviceScope.consume(OrgChartService.serviceKey);   

        this.dataCenterServiceInstance.getOrgChartInfo(this.props.listName).then((orgChartItems: any) => {
          this.setState({
            orgChartItems: orgChartItems
          });
        });

        break;
      // case EnvironmentType.Local:	            
      // case EnvironmentType.Test:	            
      default:	    
        // Webpart is running in the local workbench or from a unit test.            
        this.dataCenterServiceInstance = serviceScope.consume(MockDataService.serviceKey);

        this.dataCenterServiceInstance.getOrgChartInfo().then((orgChartItems: any) => {
          this.setState({
            orgChartItems: orgChartItems
          });
        });
    }
  }

  public render(): React.ReactElement<IOrgChartViewerProps> {
    return (
      <div className={ styles.orgChartViewer }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>

              <OrgChart tree={this.state.orgChartItems} NodeComponent={this.MyNodeComponent} />

            </div>
          </div>
        </div>
      </div>
    );
  }

  private MyNodeComponent = ({ node }) => {
    if (node.url) {
      return (
        <div className="initechNode">
          <a href={ node.url.Url } className={styles.link} >{ node.title }</a>        
        </div>
      );    
    }
    else {
      return (
        <div className="initechNode">{ node.title }</div>
      );    
    }    
  }  
}
