/* tslint:disable */
require('./OrgChartViewer.module.css');
const styles = {
  orgChartViewer: 'orgChartViewer_ef4ccaee',
  container: 'container_ef4ccaee',
  row: 'row_ef4ccaee',
  column: 'column_ef4ccaee',
  'ms-Grid': 'ms-Grid_ef4ccaee',
  link: 'link_ef4ccaee',
  title: 'title_ef4ccaee',
  subTitle: 'subTitle_ef4ccaee',
  description: 'description_ef4ccaee',
  button: 'button_ef4ccaee',
  label: 'label_ef4ccaee',
};

export default styles;
/* tslint:enable */