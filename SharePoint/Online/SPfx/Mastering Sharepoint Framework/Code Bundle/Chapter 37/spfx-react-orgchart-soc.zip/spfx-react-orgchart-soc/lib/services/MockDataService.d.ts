import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { IDataService } from './IDataService';
export declare class MockDataService implements IDataService {
    static readonly serviceKey: ServiceKey<IDataService>;
    constructor(serviceScope: ServiceScope);
    getOrgChartInfo(): Promise<any>;
}
