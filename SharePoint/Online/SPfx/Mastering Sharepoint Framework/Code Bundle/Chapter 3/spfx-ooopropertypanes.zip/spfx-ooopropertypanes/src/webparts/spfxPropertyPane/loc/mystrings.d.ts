declare interface ISpfxPropertyPaneWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpfxPropertyPaneWebPartStrings' {
  const strings: ISpfxPropertyPaneWebPartStrings;
  export = strings;
}
