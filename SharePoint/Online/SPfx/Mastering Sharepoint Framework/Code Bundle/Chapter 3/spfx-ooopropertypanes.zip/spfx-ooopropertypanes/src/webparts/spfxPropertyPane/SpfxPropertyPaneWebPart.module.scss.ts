/* tslint:disable */
require('./SpfxPropertyPaneWebPart.module.css');
const styles = {
  spfxPropertyPane: 'spfxPropertyPane_9dfd8711',
  container: 'container_9dfd8711',
  row: 'row_9dfd8711',
  column: 'column_9dfd8711',
  'ms-Grid': 'ms-Grid_9dfd8711',
  title: 'title_9dfd8711',
  subTitle: 'subTitle_9dfd8711',
  description: 'description_9dfd8711',
  button: 'button_9dfd8711',
  label: 'label_9dfd8711',
};

export default styles;
/* tslint:enable */