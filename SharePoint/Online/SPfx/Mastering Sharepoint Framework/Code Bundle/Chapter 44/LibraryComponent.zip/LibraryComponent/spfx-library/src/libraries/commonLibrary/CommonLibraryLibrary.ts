export class CommonLibraryLibrary {
  public name(): string {
    return 'CommonLibraryLibrary';
  }

  public getRandomNumber(): string {
    // Generate and return random number between 1 to 100
    let randomNumber = Math.floor(Math.random() * 100) + 1;
    return 'Random number returned from the common library is ' + randomNumber;
  }
}
