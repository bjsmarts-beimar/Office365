import * as React from 'react';
import styles from './LibraryConsumer.module.scss';
import { ILibraryConsumerProps } from './ILibraryConsumerProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as myLibrary from 'spfx-library';

export default class LibraryConsumer extends React.Component<ILibraryConsumerProps, {}> {
  public render(): React.ReactElement<ILibraryConsumerProps> {
    const myInstance = new myLibrary.CommonLibraryLibrary();

    return (
      <div className={styles.libraryConsumer}>
        <div className={styles.container}>
          <div className={styles.row}>
            <div className={styles.column}>
              <span className={styles.title}>Welcome to SharePoint!</span>
              <p className={styles.subTitle}>Customize SharePoint experiences using Web Parts.</p>
              <p>My library: {myInstance.name()}</p>
              <p>${myInstance.getRandomNumber()}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
