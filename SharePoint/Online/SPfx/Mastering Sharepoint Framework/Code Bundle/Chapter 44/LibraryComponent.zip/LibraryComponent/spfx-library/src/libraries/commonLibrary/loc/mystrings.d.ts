declare interface ICommonLibraryLibraryStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CommonLibraryLibraryStrings' {
  const strings: ICommonLibraryLibraryStrings;
  export = strings;
}
