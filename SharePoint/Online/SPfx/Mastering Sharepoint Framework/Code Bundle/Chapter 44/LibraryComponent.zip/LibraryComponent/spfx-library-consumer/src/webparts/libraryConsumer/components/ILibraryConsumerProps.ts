export interface ILibraryConsumerProps {
  description: string;
}
