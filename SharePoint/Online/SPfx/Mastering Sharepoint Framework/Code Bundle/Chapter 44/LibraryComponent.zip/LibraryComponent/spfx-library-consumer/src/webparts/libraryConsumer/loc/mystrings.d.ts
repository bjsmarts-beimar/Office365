declare interface ILibraryConsumerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'LibraryConsumerWebPartStrings' {
  const strings: ILibraryConsumerWebPartStrings;
  export = strings;
}
