/// <reference types="react" />
import * as React from 'react';
import { IReactCarouselProps } from './IReactCarouselProps';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { IReactCarouselState } from './IReactCarouselState';
export default class ReactCarousel extends React.Component<IReactCarouselProps, IReactCarouselState> {
    private dataCenterServiceInstance;
    constructor(props: IReactCarouselProps, state: IReactCarouselState);
    render(): React.ReactElement<IReactCarouselProps>;
}
