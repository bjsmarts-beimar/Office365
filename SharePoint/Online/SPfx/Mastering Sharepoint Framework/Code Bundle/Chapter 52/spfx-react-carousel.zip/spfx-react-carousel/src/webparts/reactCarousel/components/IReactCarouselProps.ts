import { ServiceScope } from '@microsoft/sp-core-library';

export interface IReactCarouselProps {
  description: string;
  serviceScope: ServiceScope;
}
