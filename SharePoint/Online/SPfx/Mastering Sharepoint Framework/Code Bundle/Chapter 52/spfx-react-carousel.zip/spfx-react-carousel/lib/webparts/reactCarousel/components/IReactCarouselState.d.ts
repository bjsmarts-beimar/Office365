export interface IReactCarouselState {
    imageURLs: string[];
}
