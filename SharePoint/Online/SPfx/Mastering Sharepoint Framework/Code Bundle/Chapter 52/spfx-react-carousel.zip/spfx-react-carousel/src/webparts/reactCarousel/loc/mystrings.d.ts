declare interface IReactCarouselWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReactCarouselWebPartStrings' {
  const strings: IReactCarouselWebPartStrings;
  export = strings;
}
