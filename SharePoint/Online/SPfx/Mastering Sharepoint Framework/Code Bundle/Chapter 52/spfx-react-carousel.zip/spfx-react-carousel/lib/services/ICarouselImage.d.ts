export interface ICarouselImage {
    FileRef: string;
}
