/* tslint:disable */
require("./ReactCarousel.module.css");
const styles = {
  reactCarousel: 'reactCarousel_5e7ab7ad',
  container: 'container_5e7ab7ad',
  row: 'row_5e7ab7ad',
  column: 'column_5e7ab7ad',
  'ms-Grid': 'ms-Grid_5e7ab7ad',
  title: 'title_5e7ab7ad',
  subTitle: 'subTitle_5e7ab7ad',
  description: 'description_5e7ab7ad',
  button: 'button_5e7ab7ad',
  label: 'label_5e7ab7ad',
};

export default styles;
/* tslint:enable */