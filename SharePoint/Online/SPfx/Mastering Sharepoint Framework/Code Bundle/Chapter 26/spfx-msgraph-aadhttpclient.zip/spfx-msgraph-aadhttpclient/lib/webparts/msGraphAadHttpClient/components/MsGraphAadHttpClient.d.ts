/// <reference types="react" />
import * as React from 'react';
import { IMsGraphAadHttpClientProps } from './IMsGraphAadHttpClientProps';
import { IMsGraphAadHttpClientState } from './IMsGraphAadHttpClientState';
export default class MsGraphAadHttpClient extends React.Component<IMsGraphAadHttpClientProps, IMsGraphAadHttpClientState> {
    constructor(props: IMsGraphAadHttpClientProps, state: IMsGraphAadHttpClientState);
    render(): React.ReactElement<IMsGraphAadHttpClientProps>;
    private getUserDetails();
}
