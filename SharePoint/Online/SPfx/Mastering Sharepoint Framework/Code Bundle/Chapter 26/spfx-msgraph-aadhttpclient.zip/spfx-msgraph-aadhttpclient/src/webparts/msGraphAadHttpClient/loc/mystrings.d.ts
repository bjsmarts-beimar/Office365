declare interface IMsGraphAadHttpClientWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MsGraphAadHttpClientWebPartStrings' {
  const strings: IMsGraphAadHttpClientWebPartStrings;
  export = strings;
}
