import { IUserItem } from './IUserItem';
export interface IMsGraphAadHttpClientState {
    users: Array<IUserItem>;
}
