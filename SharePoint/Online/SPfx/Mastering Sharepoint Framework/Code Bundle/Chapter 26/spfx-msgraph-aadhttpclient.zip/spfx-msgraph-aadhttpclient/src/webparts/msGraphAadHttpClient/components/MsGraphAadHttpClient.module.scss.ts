/* tslint:disable */
require('./MsGraphAadHttpClient.module.css');
const styles = {
  msGraphAadHttpClient: 'msGraphAadHttpClient_66ab58d7',
  form: 'form_66ab58d7',
  container: 'container_66ab58d7',
  row: 'row_66ab58d7',
  column: 'column_66ab58d7',
  'ms-Grid': 'ms-Grid_66ab58d7',
  title: 'title_66ab58d7',
  subTitle: 'subTitle_66ab58d7',
  description: 'description_66ab58d7',
  button: 'button_66ab58d7',
  label: 'label_66ab58d7',
};

export default styles;
/* tslint:enable */