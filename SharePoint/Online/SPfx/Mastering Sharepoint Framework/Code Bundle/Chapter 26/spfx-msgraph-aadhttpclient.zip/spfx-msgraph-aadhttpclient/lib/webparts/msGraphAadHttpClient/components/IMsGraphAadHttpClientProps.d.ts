import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IMsGraphAadHttpClientProps {
    description: string;
    context: WebPartContext;
}
