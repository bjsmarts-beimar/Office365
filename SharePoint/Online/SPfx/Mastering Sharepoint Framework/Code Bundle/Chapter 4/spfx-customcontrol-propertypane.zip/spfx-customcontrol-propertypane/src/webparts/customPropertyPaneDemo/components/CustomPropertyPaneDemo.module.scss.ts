/* tslint:disable */
require("./CustomPropertyPaneDemo.module.css");
const styles = {
  customPropertyPaneDemo: 'customPropertyPaneDemo_6714b7b9',
  container: 'container_6714b7b9',
  row: 'row_6714b7b9',
  column: 'column_6714b7b9',
  'ms-Grid': 'ms-Grid_6714b7b9',
  title: 'title_6714b7b9',
  subTitle: 'subTitle_6714b7b9',
  description: 'description_6714b7b9',
  button: 'button_6714b7b9',
  label: 'label_6714b7b9',
};

export default styles;
/* tslint:enable */