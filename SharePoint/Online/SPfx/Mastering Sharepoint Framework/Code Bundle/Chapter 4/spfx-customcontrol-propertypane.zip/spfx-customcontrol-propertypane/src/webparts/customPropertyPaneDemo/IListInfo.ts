export interface IListInfo {
    Id: string;
    Title: string;
  }