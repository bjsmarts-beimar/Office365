/// <reference types="react" />
import * as React from 'react';
import { ICustomPropertyPaneDemoProps } from './ICustomPropertyPaneDemoProps';
export default class CustomPropertyPaneDemo extends React.Component<ICustomPropertyPaneDemoProps, {}> {
    render(): React.ReactElement<ICustomPropertyPaneDemoProps>;
}
