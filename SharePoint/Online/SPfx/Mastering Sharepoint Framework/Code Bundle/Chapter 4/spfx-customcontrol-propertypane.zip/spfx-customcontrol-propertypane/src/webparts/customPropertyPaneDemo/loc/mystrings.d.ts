declare interface ICustomPropertyPaneDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListFieldLabel: string;
}

declare module 'CustomPropertyPaneDemoWebPartStrings' {
  const strings: ICustomPropertyPaneDemoWebPartStrings;
  export = strings;
}
