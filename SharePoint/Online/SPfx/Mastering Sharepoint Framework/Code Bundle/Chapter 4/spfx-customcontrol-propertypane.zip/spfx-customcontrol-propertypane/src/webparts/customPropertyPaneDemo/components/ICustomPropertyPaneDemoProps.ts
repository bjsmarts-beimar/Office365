export interface ICustomPropertyPaneDemoProps {
  listName: string;
}
