/* tslint:disable */
require('./TreeViewExample.module.css');
const styles = {
  treeViewExample: 'treeViewExample_9ebd8674',
  container: 'container_9ebd8674',
  row: 'row_9ebd8674',
  column: 'column_9ebd8674',
  'ms-Grid': 'ms-Grid_9ebd8674',
  title: 'title_9ebd8674',
  subTitle: 'subTitle_9ebd8674',
  description: 'description_9ebd8674',
  button: 'button_9ebd8674',
  label: 'label_9ebd8674',
};

export default styles;
/* tslint:enable */