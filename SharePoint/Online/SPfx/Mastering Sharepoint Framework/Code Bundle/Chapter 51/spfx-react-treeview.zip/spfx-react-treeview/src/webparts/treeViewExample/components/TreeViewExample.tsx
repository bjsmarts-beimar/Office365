import * as React from 'react';
import styles from './TreeViewExample.module.scss';
import { ITreeViewExampleProps } from './ITreeViewExampleProps';
import { ITreeViewExampleState } from './ITreeViewExampleState';
import SuperTreeview from 'react-super-treeview';
import { escape } from '@microsoft/sp-lodash-subset';

const sessionStorageSelectedNodeKey = "sessionStorageSelectedNodeKey";

export default class TreeViewExample extends React.Component<ITreeViewExampleProps, ITreeViewExampleState> {
  constructor (){
    super();

    this.state = {
      data: [
          {
              id: 1,
              name: 'Parent A'
          },
          {
              id: 2,
              name: 'Parent B',
              isExpanded: true,
              isChecked: true,
              children: [
                  {
                      id: 21,
                      name: 'Child 1',
                      isExpanded: true,
                      children: [
                          {
                              id: 5,
                              name: "Grand Child",
                              isExpanded: true
                          }
                      ]
                  },
                  {
                      id: 22,
                      name: 'Child 2'
                  },
                  {
                      id: 23,
                      name: 'Child 3'
                  },
                  {
                      id: 24,
                      name: 'Child 4'
                  }
              ]
          }
      ]
    };
  }
  
  public render(): React.ReactElement<ITreeViewExampleProps> {
    return (
      // RENDER THE COMPONENT
      <div className={ styles.treeViewExample }>  
        <div className={ styles.container }>  
          <div className={ styles.row }>  
            <div className={ styles.column }>  
              
              <SuperTreeview
                data={ this.state.data }
                noChildrenAvailableMessage= ''
                isDeletable= {(node, depth) => {
                  return false;
                }}
                onUpdateCb={(updatedData) => {
                  this.setState({data: updatedData});
                  let selectedNodeName: string = sessionStorage.getItem(sessionStorageSelectedNodeKey);

                  resetNodes(updatedData);
          
                  function resetNodes(nodes){
                      nodes.forEach((node)=>{
                          if (node.name !== selectedNodeName) {
                            node.isChecked = false;
                          }
                          
                          if(node.children){
                            resetNodes(node.children);
                          }
                      });
                  }

                  sessionStorage.removeItem(sessionStorageSelectedNodeKey);
                }}
                onCheckToggleCb={(nodes, depth)=>{
                    sessionStorage.setItem(sessionStorageSelectedNodeKey, nodes[0].name);
              }}
              />        
            </div>  
          </div>  
        </div>  
      </div>  
    );
  }
}
