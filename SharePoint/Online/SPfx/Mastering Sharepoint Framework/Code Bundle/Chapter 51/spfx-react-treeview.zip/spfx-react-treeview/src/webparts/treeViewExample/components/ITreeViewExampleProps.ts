export interface ITreeViewExampleProps {
  description: string;
}
