/// <reference types="react" />
import * as React from 'react';
import { ITreeViewExampleProps } from './ITreeViewExampleProps';
import { ITreeViewExampleState } from './ITreeViewExampleState';
export default class TreeViewExample extends React.Component<ITreeViewExampleProps, ITreeViewExampleState> {
    constructor();
    render(): React.ReactElement<ITreeViewExampleProps>;
}
