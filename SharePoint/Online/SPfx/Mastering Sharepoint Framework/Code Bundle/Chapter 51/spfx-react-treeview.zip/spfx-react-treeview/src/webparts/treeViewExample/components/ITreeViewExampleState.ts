export interface ITreeViewExampleState {
    data: any;
}