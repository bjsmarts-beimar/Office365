declare interface ITreeViewExampleWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TreeViewExampleWebPartStrings' {
  const strings: ITreeViewExampleWebPartStrings;
  export = strings;
}
