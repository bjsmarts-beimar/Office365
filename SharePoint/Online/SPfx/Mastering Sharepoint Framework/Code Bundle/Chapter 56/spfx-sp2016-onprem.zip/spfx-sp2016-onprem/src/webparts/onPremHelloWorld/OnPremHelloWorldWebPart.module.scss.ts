/* tslint:disable */
require('./OnPremHelloWorldWebPart.module.css');
const styles = {
  onPremHelloWorld: 'onPremHelloWorld_29e0d683',
  container: 'container_29e0d683',
  row: 'row_29e0d683',
  column: 'column_29e0d683',
  'ms-Grid': 'ms-Grid_29e0d683',
  title: 'title_29e0d683',
  subTitle: 'subTitle_29e0d683',
  description: 'description_29e0d683',
  button: 'button_29e0d683',
  label: 'label_29e0d683',
};

export default styles;
/* tslint:enable */