declare interface IOnPremHelloWorldWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'OnPremHelloWorldWebPartStrings' {
  const strings: IOnPremHelloWorldWebPartStrings;
  export = strings;
}
