import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';

import * as strings from 'HelloSp2019WebPartStrings';
import HelloSp2019 from './components/HelloSp2019';
import { IHelloSp2019Props } from './components/IHelloSp2019Props';

export interface IHelloSp2019WebPartProps {
  description: string;
}

export default class HelloSp2019WebPart extends BaseClientSideWebPart<IHelloSp2019WebPartProps> {

  public render(): void {
    const element: React.ReactElement<IHelloSp2019Props > = React.createElement(
      HelloSp2019,
      {
        description: this.properties.description
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
