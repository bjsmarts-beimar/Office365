/// <reference types="react" />
import * as React from 'react';
import { IHelloSp2019Props } from './IHelloSp2019Props';
export default class HelloSp2019 extends React.Component<IHelloSp2019Props, {}> {
    render(): React.ReactElement<IHelloSp2019Props>;
}
