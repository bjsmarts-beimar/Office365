/* tslint:disable */
require('./HelloSp2019.module.css');
const styles = {
  helloSp2019: 'helloSp2019_68e2b220',
  container: 'container_68e2b220',
  row: 'row_68e2b220',
  column: 'column_68e2b220',
  'ms-Grid': 'ms-Grid_68e2b220',
  title: 'title_68e2b220',
  subTitle: 'subTitle_68e2b220',
  description: 'description_68e2b220',
  button: 'button_68e2b220',
  label: 'label_68e2b220',
};

export default styles;
/* tslint:enable */