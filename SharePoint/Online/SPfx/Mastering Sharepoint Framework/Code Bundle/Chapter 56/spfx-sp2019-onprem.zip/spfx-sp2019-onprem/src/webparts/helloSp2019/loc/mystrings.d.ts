declare interface IHelloSp2019WebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HelloSp2019WebPartStrings' {
  const strings: IHelloSp2019WebPartStrings;
  export = strings;
}
