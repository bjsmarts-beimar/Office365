import * as React from 'react';
import styles from './HelloSp2019.module.scss';
import { IHelloSp2019Props } from './IHelloSp2019Props';
import { escape } from '@microsoft/sp-lodash-subset';

export default class HelloSp2019 extends React.Component < IHelloSp2019Props, {} > {
  public render(): React.ReactElement<IHelloSp2019Props> {
    return(
      <div className = { styles.helloSp2019 } >
  <div className={styles.container}>
    <div className={styles.row}>
      <div className={styles.column}>
        <span className={styles.title}>Welcome to SharePoint!</span>
        <p className={styles.subTitle}>Customize SharePoint experiences using Web Parts.</p>
        <p className={styles.description}>{escape(this.props.description)}</p>
        <a href='https://aka.ms/spfx' className={styles.button}>
          <span className={styles.label}>Learn more</span>
        </a>
      </div>
    </div>
  </div>
      </div >
    );
  }
}
