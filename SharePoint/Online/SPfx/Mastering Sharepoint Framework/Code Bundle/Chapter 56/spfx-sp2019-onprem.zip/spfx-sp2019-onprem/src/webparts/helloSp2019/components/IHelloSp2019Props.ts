export interface IHelloSp2019Props {
  description: string;
}
