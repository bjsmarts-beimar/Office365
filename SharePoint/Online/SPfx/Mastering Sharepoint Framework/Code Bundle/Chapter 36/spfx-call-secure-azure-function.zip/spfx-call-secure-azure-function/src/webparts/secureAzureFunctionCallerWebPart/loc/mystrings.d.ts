declare interface ISecureAzureFunctionCallerWebPartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SecureAzureFunctionCallerWebPartWebPartStrings' {
  const strings: ISecureAzureFunctionCallerWebPartWebPartStrings;
  export = strings;
}
