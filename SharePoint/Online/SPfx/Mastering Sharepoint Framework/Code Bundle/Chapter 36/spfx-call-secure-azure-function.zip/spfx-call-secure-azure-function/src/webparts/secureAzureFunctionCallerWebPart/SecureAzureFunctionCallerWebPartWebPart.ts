import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './SecureAzureFunctionCallerWebPartWebPart.module.scss';
import * as strings from 'SecureAzureFunctionCallerWebPartWebPartStrings';

import { AadHttpClient, HttpClientResponse } from '@microsoft/sp-http';

export interface ISecureAzureFunctionCallerWebPartWebPartProps {
  description: string;
}

export default class SecureAzureFunctionCallerWebPartWebPart extends BaseClientSideWebPart<ISecureAzureFunctionCallerWebPartWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
      <div class="${ styles.secureAzureFunctionCallerWebPart }">
        <div class="${ styles.container }">
          <div class="${ styles.row }">
            <div class="${ styles.column }">
              <span class="${ styles.title }">Welcome to SharePoint!</span>
              <p class="${ styles.subTitle }">Current user claims from Azure function</p>
            </div>
          </div>
        </div>
      </div>
      <div class="${styles.tableContainer}">
            <table class='claimsTable'>
            </table>
      </div>
      `;

    this.context.aadHttpClientFactory
      .getClient('https://tenant.onmicrosoft.com/cf981eac-50dc-4221-8882-515a4d31328d')
        .then((client: AadHttpClient): void => {
          client
            .get('https://spfxsecurecaller.azurewebsites.net/api/UserInformation', AadHttpClient.configurations.v1)
            .then((response: HttpClientResponse): Promise<JSON> => {
              return response.json();
            })
            .then((responseJSON: JSON): void => {
              // Render JSON in table
              var claimsTable = this.domElement.getElementsByClassName("claimsTable")[0];

              for (var key in responseJSON) {
                var trElement = document.createElement("tr");
                trElement.innerHTML = `<td class="${styles.tableCell}">${key}</td><td class="${styles.tableCell}">${responseJSON[key]}</td>`;
                claimsTable.appendChild(trElement);
              }
            });
        });
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
