define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "ImageGalleryNameFieldLabel": "Image Gallery",
    "ImagesToDisplayFieldLabel": "Number of images to display",
  }
});