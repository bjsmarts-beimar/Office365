export interface IAdaptiveCardsImageGalleryState {
    galleryItems: any[];
    isLoading: boolean;
    showErrorMessage: boolean;
}