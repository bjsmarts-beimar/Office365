declare interface IAdaptiveCardsImageGalleryWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ImageGalleryNameFieldLabel: string;
  ImagesToDisplayFieldLabel: string;
}

declare module 'AdaptiveCardsImageGalleryWebPartStrings' {
  const strings: IAdaptiveCardsImageGalleryWebPartStrings;
  export = strings;
}
