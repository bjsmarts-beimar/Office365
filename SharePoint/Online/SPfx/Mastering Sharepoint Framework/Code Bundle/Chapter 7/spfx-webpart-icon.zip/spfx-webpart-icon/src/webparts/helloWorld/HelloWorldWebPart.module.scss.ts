/* tslint:disable */
require("./HelloWorldWebPart.module.css");
const styles = {
  helloWorld: 'helloWorld_841b47f1',
  container: 'container_841b47f1',
  row: 'row_841b47f1',
  column: 'column_841b47f1',
  'ms-Grid': 'ms-Grid_841b47f1',
  title: 'title_841b47f1',
  subTitle: 'subTitle_841b47f1',
  description: 'description_841b47f1',
  button: 'button_841b47f1',
  label: 'label_841b47f1',
};

export default styles;
/* tslint:enable */